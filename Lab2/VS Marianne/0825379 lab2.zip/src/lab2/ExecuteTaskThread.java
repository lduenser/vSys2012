/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.Socket;
import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ternekma
 */
public class ExecuteTaskThread implements Runnable {
       private final BufferedReader inFromTaskEngine;
       private final DataOutputStream outToTaskEngine;
       private final Task task;
       
       private INotifyClient notifyRemObj;
       private  byte [] mybytearray;
       private Company company;

       public ExecuteTaskThread(Task task, Socket socket, byte [] mybytearray,INotifyClient notifyRemObj,Company company)
           throws IOException {
           this.mybytearray=mybytearray;
           this.task=task;
           this.inFromTaskEngine = new BufferedReader(new InputStreamReader (socket.getInputStream()));
           this.outToTaskEngine= new DataOutputStream(socket.getOutputStream());
           this.company=company;

           this.notifyRemObj=notifyRemObj;
       }

        public void run()  {
          int costs=0;
          boolean bAddExeCnt=false;
          GregorianCalendar startDate =new GregorianCalendar();
          try {
            try {
                notifyRemObj.notifyMessage("Execution of task " + task.id + " started!" );
                company.incStartExecutions(); bAddExeCnt=true;
                outToTaskEngine.write(mybytearray, 0, mybytearray.length);
                outToTaskEngine.flush();
                String line;
                boolean end = false;
                //falls er hier nicht mehr raus kommt
                while ((!end) && ((line = inFromTaskEngine.readLine()) != null)) {
                    line = line.trim();
                    if (line.equalsIgnoreCase("END_OF_OUTPUT")) {        
                        end = true;
                    } else {
                        task.output = task.output + line + "\n";
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(ExecuteTaskThread.class.getName()).log(Level.SEVERE, null, ex);
            } 
          } finally {
              GregorianCalendar endDate = new GregorianCalendar();
              // Get the represented date in milliseconds
              long time1 = startDate.getTimeInMillis();
              long time2 = endDate.getTimeInMillis();
              // Calculate difference in milliseconds
              long diff = time2 - time1;
              // Difference in minutes
              double diffMin = ((double)diff) / (60 * 1000);
              costs=(int) Math.ceil(diffMin * 10);
              try {
                 notifyRemObj.notifyMessage("Execution of task " + task.id + " finished!" );
              } catch (RemoteException ex) {
                 System.out.println("Client, who has executed a task on tasengine "+task.engine_host+" has gone during execution!");
              }
              if (task!=null) {
                task.Status=UtilityClass.TaskStatus.stateFinished;
                task.output = task.output + "Finished Task "+task.id+"!";
                task.costs=task.costs+costs;
              }
              if (company!=null) {
                //if there went something wrong and the started executions are not beein incremented already
                if (!bAddExeCnt) {  company.incStartExecutions(); }
                //increment finished executions
                company.incFinishedExecutions(task.expectedload);
                //decrement costs
                company.incCredits(-costs,true);
              }

          }
        }

}
